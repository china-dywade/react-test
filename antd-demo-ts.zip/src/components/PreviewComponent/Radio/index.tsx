import * as React from 'react';
export interface RadioComponentProps {
  
}
 
export interface RadioComponentState {
  
}
 
class RadioComponent extends React.Component<RadioComponentProps, RadioComponentState> {
  constructor(props: RadioComponentProps) {
    super(props);
    // this.state = { :  };
  }
  render() { 
    return ( 
      <div>

      </div>
     );
  }
}
 
export default RadioComponent;