import * as React from 'react';

import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";

import { Radio, Checkbox, Row, Col } from 'antd';

export interface Props {
  data: any;
}

export interface State {
  title: string;
  value: any[];
  type:string;
}

class InputDefault extends React.Component<Props, State> {

  constructor(props: Props) {
    super(props);
    this.state = { ...this.props.data };
    console.log(this.state,'result'); 
  }

  // componentWillReceiveProps(nextProps: any) {
  //   console.log(nextProps,'nextProps');
    
  //   this.setState({
  //     type: nextProps.data.type
  //   })
  // }




  handleClick = (ev:any) => {

  }

  inputChange = (e: any) => {
    this.setState({
      value: e.target.value
    });
    this.props.data.callBack(e.target.value);
  }

  onDragEnd = (result:any) => {
    const { source, destination, draggableId } = result;
    if (!destination) {
      return;
    }
    let arr = [...this.state.value];
    const [remove] = arr.splice(source.index, 1);
    arr.splice(destination.index, 0, remove);
    this.setState({
      value:arr
    },()=>{
        this.props.data.callBack(arr);
    })
   
  }

  onDragStart = (result:any) => {
    console.log(result,'result');  
  }


  render() {
    return (
      <DragDropContext onDragEnd={this.onDragEnd}>

              <Droppable droppableId="drag" type="DROG">
                {
                  (provided, snapshot) => (

                    <div className="" ref={provided.innerRef}   {...provided.droppableProps} >
                      <div className="mbt_5">
                        <span>{this.state.title}</span> 
                      </div>  
                      {this.state.value.map((comp: any, index: number): any => {
                      
                        return (
                          <Draggable key={comp.id} draggableId={`${comp}_${comp.id}`} index={index}>
                            {(provided, snapshot) => (

                              <div
                         
                                key={`${comp}_${comp.id}`}
                                ref={provided.innerRef}
                                {...provided.draggableProps}
                                {...provided.dragHandleProps}
                
                              >
                       
                                {
                                  this.state.type == "radio" ?
                                    <Radio.Group  >
                                      <Row >                           
                                          <Col span={24} key={comp.id} className="mbt_5">
                                            <Radio value={comp.value}>{comp.value}</Radio>
                                          </Col>                                          
                                      </Row>
                                    </Radio.Group>
                                    :
                                    <Checkbox.Group >
                                      <Row>                              
                                        <Col span={24} key={comp.id} className="mbt_5">
                                          <Checkbox value={comp.value}>{comp.value}</Checkbox>
                                        </Col>                                                                              
                                      </Row>
                                    </Checkbox.Group>
                                }

                              </div>
                            )}
                          </Draggable>
                        )
                      })
                      }
                
                    </div>

                  )
                }

              </Droppable>
        
      </DragDropContext>
    )
  }
}
export default InputDefault;