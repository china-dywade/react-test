import { combineReducers } from 'redux';
import home from '../reducer/home';
const reducers: any = combineReducers({
  home
})
export default reducers